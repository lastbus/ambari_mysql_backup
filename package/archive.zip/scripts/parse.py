#!/usr/bin/python

conf = {}
for line in open('/etc/mysql_backup/conf/mysql_backup.properties'):
	if len(line) >= 3:
		words = line.split("=")
		conf[words[0]] = words[1]
		print "%s = %s" % (words[0], words[0])


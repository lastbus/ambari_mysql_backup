import os
import sys

from resource_management.libraries.script.script import Script
from resource_management.libraries.functions import conf_select,stack_select
from resource_management.libraries.functions.constants import StackFeature
from resource_management.libraries.functions.version import compare_versions, format_stack_version
from resource_management.libraries.functions.stack_features import check_stack_feature
from resource_management.core.resources.system import Directory, File
from resource_management.core.resources.service import ServiceConfig
from resource_management.core.source import InlineTemplate, Template
from ambari_commons import OSConst
from ambari_commons.os_family_impl import OsFamilyFuncImpl, OsFamilyImpl

@OsFamilyFuncImpl(os_family=OsFamilyImpl.DEFAULT)
def backup(type = None, upgrade_type=None):
    import params
    Directory(params.conf_dir,
              owner='root',
              create_parents = True,
              group='root'
              )
    configFile("mysql_backup.properties", template_name="mysql_backup.properties.j2")
    

@OsFamilyFuncImpl(os_family=OSConst.WINSRV_FAMILY)
def backup(type = None, upgrade_type=None):
    import params
    Directory(params.conf_dir,
              owner='root',
              create_parents = True,
              group='root'
              )
    configFile("mysql_backup.properties", template_name="mysql_backup.properties.j2")
    

def configFile(name, template_name=None, mode=None):
    import params
    File(os.path.join(params.conf_dir, name),
         content=Template(template_name),
         owner='root',
         group='root',
         mode=mode
         )


